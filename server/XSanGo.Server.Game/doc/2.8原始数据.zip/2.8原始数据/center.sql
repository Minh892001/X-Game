/*
Navicat MySQL Data Transfer

Source Server         : 192.168.108.208-泰国测试2
Source Server Version : 50619
Source Host           : 192.168.108.208:3306
Source Database       : xsg_th_center

Target Server Type    : MYSQL
Target Server Version : 50619
File Encoding         : 65001

Date: 2016-08-02 13:49:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
`account`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`channel_id`  int(11) NOT NULL ,
`create_time`  datetime NOT NULL ,
`id`  int(11) NOT NULL ,
`last_login_time`  datetime NULL DEFAULT NULL ,
`mobile`  varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`password`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_count`  int(11) NOT NULL ,
`valid`  bit(1) NOT NULL ,
`recent_servers`  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`active`  int(11) NULL DEFAULT 0 ,
`forzen_expire_time`  datetime NULL DEFAULT NULL ,
`charge_count`  int(11) NULL DEFAULT 0 ,
`max_level`  int(11) NULL DEFAULT 0 ,
`register_mac`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' ,
PRIMARY KEY (`account`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `active_code`
-- ----------------------------
DROP TABLE IF EXISTS `active_code`;
CREATE TABLE `active_code` (
`code`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`account`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`use_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`code`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `cdk_detail`
-- ----------------------------
DROP TABLE IF EXISTS `cdk_detail`;
CREATE TABLE `cdk_detail` (
`cdk`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`max_use_time`  int(11) NOT NULL ,
`use_time`  int(11) NOT NULL ,
`group_id`  int(11) NOT NULL ,
PRIMARY KEY (`cdk`),
FOREIGN KEY (`group_id`) REFERENCES `cdk_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `cdk_group`
-- ----------------------------
DROP TABLE IF EXISTS `cdk_group`;
CREATE TABLE `cdk_group` (
`id`  int(11) NOT NULL ,
`begin_time`  datetime NOT NULL ,
`category`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`channels`  varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`servers`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`charge_money`  int(11) NOT NULL ,
`content`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`end_time`  datetime NOT NULL ,
`faction_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`max_level`  int(11) NOT NULL ,
`min_level`  int(11) NOT NULL ,
`name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`remark`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `channel`
-- ----------------------------
DROP TABLE IF EXISTS `channel`;
CREATE TABLE `channel` (
`id`  int(11) NOT NULL ,
`callback_url`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`name`  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`order_url`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `charge`
-- ----------------------------
DROP TABLE IF EXISTS `charge`;
CREATE TABLE `charge` (
`order_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`account`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`cent`  int(11) NOT NULL ,
`channel`  int(11) NOT NULL ,
`complete_time`  datetime NULL DEFAULT NULL ,
`create_time`  datetime NOT NULL ,
`params`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`server_id`  int(11) NOT NULL ,
`state`  int(11) NOT NULL ,
`currency`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`card_type`  int(11) NULL DEFAULT NULL ,
`pm_id`  int(11) NULL DEFAULT NULL ,
PRIMARY KEY (`order_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `game_server`
-- ----------------------------
DROP TABLE IF EXISTS `game_server`;
CREATE TABLE `game_server` (
`id`  int(11) NOT NULL ,
`host`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`is_new`  bit(1) NOT NULL ,
`name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`cp_show_only`  tinyint(4) NOT NULL ,
`cp_enter_only`  tinyint(4) NOT NULL ,
`online_limit`  int(11) NOT NULL ,
`target_id`  int(11) NOT NULL DEFAULT 0 ,
`show_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Indexes structure for table account
-- ----------------------------
CREATE UNIQUE INDEX `account` ON `account`(`account`) USING BTREE ;
CREATE UNIQUE INDEX `id` ON `account`(`id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table active_code
-- ----------------------------
CREATE UNIQUE INDEX `code` ON `active_code`(`code`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table cdk_detail
-- ----------------------------
CREATE UNIQUE INDEX `cdk` ON `cdk_detail`(`cdk`) USING BTREE ;
CREATE INDEX `FK2019F206E2321853` ON `cdk_detail`(`group_id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table cdk_group
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `cdk_group`(`id`) USING BTREE ;
CREATE UNIQUE INDEX `category` ON `cdk_group`(`category`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table channel
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `channel`(`id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table game_server
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `game_server`(`id`) USING BTREE ;
