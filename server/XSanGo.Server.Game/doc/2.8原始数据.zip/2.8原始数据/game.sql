SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `arena_award_log`
-- ----------------------------
DROP TABLE IF EXISTS `arena_award_log`;
CREATE TABLE `arena_award_log` (
`award_date`  datetime NOT NULL ,
`award_str`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`award_type`  int(3) NULL DEFAULT 1 ,
PRIMARY KEY (`award_date`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `arena_rank`
-- ----------------------------
DROP TABLE IF EXISTS `arena_rank`;
CREATE TABLE `arena_rank` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`rank`  int(11) NULL DEFAULT 0 ,
`robot`  bit(1) NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `arena_rank_copy`
-- ----------------------------
DROP TABLE IF EXISTS `arena_rank_copy`;
CREATE TABLE `arena_rank_copy` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attack_fight_sum`  int(11) NULL DEFAULT 1 ,
`attack_win_sum`  int(11) NULL DEFAULT 1 ,
`challenge`  int(11) NULL DEFAULT 0 ,
`challenge_buy`  int(11) NULL DEFAULT 0 ,
`challenge_buy_date`  datetime NULL DEFAULT NULL ,
`challenge_money`  int(11) NULL DEFAULT 0 ,
`clear_cd_Date`  datetime NULL DEFAULT NULL ,
`clear_cd_num`  int(11) NULL DEFAULT 0 ,
`exchange_item_str`  varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`exchange_refresh_date`  datetime NULL DEFAULT NULL ,
`exchange_refresh_num`  int(11) NULL DEFAULT 0 ,
`fight_date`  datetime NULL DEFAULT NULL ,
`guard_fight_sum`  int(11) NULL DEFAULT 1 ,
`guard_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`guard_win_num`  int(11) NULL DEFAULT 0 ,
`guard_win_sum`  int(11) NULL DEFAULT 1 ,
`max_rank`  int(11) NULL DEFAULT 0 ,
`rank`  int(11) NULL DEFAULT 0 ,
`robot`  bit(1) NULL DEFAULT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`show_report_date`  datetime NULL DEFAULT NULL ,
`sneer_id`  int(11) NULL DEFAULT 0 ,
`sneer_str`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `auction_house_item`
-- ----------------------------
DROP TABLE IF EXISTS `auction_house_item`;
CREATE TABLE `auction_house_item` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`base_price`  bigint(20) NOT NULL DEFAULT 0 ,
`fixed_price`  bigint(20) NOT NULL DEFAULT '-1' ,
`bid_num`  int(11) NOT NULL DEFAULT 0 ,
`current_price`  bigint(20) NOT NULL DEFAULT 0 ,
`bid_role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`start_time`  datetime NOT NULL ,
`end_time`  bigint(20) NOT NULL DEFAULT 0 ,
`item_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`item_type`  int(11) NOT NULL DEFAULT 0 ,
`item_num`  int(11) NOT NULL DEFAULT 0 ,
`pause_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `auction_house_item_log`
-- ----------------------------
DROP TABLE IF EXISTS `auction_house_item_log`;
CREATE TABLE `auction_house_item_log` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`auction_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`item_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`data`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`update_time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2

;

-- ----------------------------
-- Table structure for `auction_house_log`
-- ----------------------------
DROP TABLE IF EXISTS `auction_house_log`;
CREATE TABLE `auction_house_log` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`other_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`operation_type`  int(11) NOT NULL ,
`template_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`update_time`  datetime NOT NULL ,
`auction_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`num`  int(11) NULL DEFAULT NULL ,
`money`  bigint(20) NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=3

;

-- ----------------------------
-- Table structure for `auction_house_record`
-- ----------------------------
DROP TABLE IF EXISTS `auction_house_record`;
CREATE TABLE `auction_house_record` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`auction_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`price`  bigint(20) NOT NULL DEFAULT 0 ,
`count`  int(11) NOT NULL DEFAULT 0 ,
`time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `battle_power_snapshot`
-- ----------------------------
DROP TABLE IF EXISTS `battle_power_snapshot`;
CREATE TABLE `battle_power_snapshot` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`data`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`power`  int(11) NOT NULL ,
`role_level`  int(11) NOT NULL ,
`role_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `chat_message`
-- ----------------------------
DROP TABLE IF EXISTS `chat_message`;
CREATE TABLE `chat_message` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`acceptor_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`channel`  int(11) NOT NULL ,
`content`  varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL ,
`create_time`  datetime NOT NULL ,
`sender_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=7

;

-- ----------------------------
-- Table structure for `chat_message_offline`
-- ----------------------------
DROP TABLE IF EXISTS `chat_message_offline`;
CREATE TABLE `chat_message_offline` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`acceptor_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`channel`  int(11) NOT NULL ,
`create_time`  datetime NOT NULL ,
`sender_content`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_icon`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_level`  smallint(6) NOT NULL ,
`sender_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_offical_rankId`  int(11) NOT NULL ,
`sender_vip`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK3A39F6C42AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=4

;

-- ----------------------------
-- Table structure for `faction`
-- ----------------------------
DROP TABLE IF EXISTS `faction`;
CREATE TABLE `faction` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`announcement`  varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL ,
`boss_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`creator_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`exp`  int(11) NOT NULL ,
`icon`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`level`  int(11) NOT NULL ,
`name`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`qq`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' ,
`state`  smallint(6) NOT NULL ,
`join_type`  int(11) NULL DEFAULT 1 ,
`last_open_copy_time`  datetime NULL DEFAULT NULL ,
`open_copy_num`  int(11) NOT NULL ,
`shop_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`shop_refresh_date`  datetime NULL DEFAULT NULL ,
`honor`  int(11) NULL DEFAULT 0 ,
`rename_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
UNIQUE INDEX `name` (`name`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `faction_copy`
-- ----------------------------
DROP TABLE IF EXISTS `faction_copy`;
CREATE TABLE `faction_copy` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`copy_id`  int(11) NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`stage_num`  int(11) NOT NULL ,
`monster_json`  varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`open_date`  datetime NULL DEFAULT NULL ,
`challenge_time`  bigint(20) NOT NULL ,
`harm_blood`  int(11) NOT NULL ,
`addition_type`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `faction_history`
-- ----------------------------
DROP TABLE IF EXISTS `faction_history`;
CREATE TABLE `faction_history` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' ,
`create_time`  datetime NOT NULL ,
`remark`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_name`  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' ,
`vip_level`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
FOREIGN KEY (`faction_id`) REFERENCES `faction` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK927CC971EEAAB2D7` (`faction_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `faction_member`
-- ----------------------------
DROP TABLE IF EXISTS `faction_member`;
CREATE TABLE `faction_member` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`contribution`  int(11) NOT NULL ,
`duty_id`  int(11) NOT NULL ,
`last_time`  datetime NULL DEFAULT NULL ,
`level`  int(11) NOT NULL ,
`name`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`offline_time`  datetime NULL DEFAULT NULL ,
`participate_time`  datetime NULL DEFAULT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_challenge_date`  datetime NULL DEFAULT NULL ,
`challenge_num`  int(11) NOT NULL ,
`honor`  int(11) NULL DEFAULT 0 ,
`buy_shop_ids`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' ,
`apply_date`  datetime NULL DEFAULT NULL ,
`death_date`  datetime NULL DEFAULT NULL ,
`gvg_end_date`  datetime NULL DEFAULT NULL ,
`sum_copy_harm`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
FOREIGN KEY (`faction_id`) REFERENCES `faction` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK4F17161DEEAAB2D7` (`faction_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `faction_member_rank`
-- ----------------------------
DROP TABLE IF EXISTS `faction_member_rank`;
CREATE TABLE `faction_member_rank` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NOT NULL ,
`honor`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `faction_req`
-- ----------------------------
DROP TABLE IF EXISTS `faction_req`;
CREATE TABLE `faction_req` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`req_date`  datetime NULL DEFAULT '1970-01-01 00:00:00' ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `fight_movie`
-- ----------------------------
DROP TABLE IF EXISTS `fight_movie`;
CREATE TABLE `fight_movie` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`data`  mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`start_time`  datetime NOT NULL ,
`type`  int(11) NOT NULL DEFAULT 0 ,
`self_role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`opponent_role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`result`  int(11) NOT NULL DEFAULT 0 ,
`remain_hero`  int(11) NOT NULL DEFAULT 0 ,
`self_formation_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`opponent_formation_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`end_time`  datetime NULL DEFAULT NULL ,
`validated`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
INDEX `end_time` (`end_time`) USING BTREE ,
INDEX `validated` (`validated`) USING BTREE ,
INDEX `type` (`type`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `friend_applying_history`
-- ----------------------------
DROP TABLE IF EXISTS `friend_applying_history`;
CREATE TABLE `friend_applying_history` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`player`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`date`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`type`  int(11) NOT NULL ,
`target`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`target`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK6C5FF48AA41EF88A` (`target`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `haoqingbao_item_packet`
-- ----------------------------
DROP TABLE IF EXISTS `haoqingbao_item_packet`;
CREATE TABLE `haoqingbao_item_packet` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`receiver_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`item_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`num`  int(11) NOT NULL DEFAULT 0 ,
`lucky_star`  int(11) NOT NULL DEFAULT 0 ,
`send_date`  datetime NOT NULL ,
`receive_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `hero_practice`
-- ----------------------------
DROP TABLE IF EXISTS `hero_practice`;
CREATE TABLE `hero_practice` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`hero_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`script_id`  int(11) NOT NULL ,
`prop_name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`color`  int(11) NOT NULL ,
`level`  int(11) NOT NULL ,
`exp`  int(11) NOT NULL ,
`add_value`  int(11) NOT NULL ,
`next_up_exp`  int(11) NOT NULL ,
`indexof`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
INDEX `hero_practice_index_hero_id` (`hero_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `invite_code`
-- ----------------------------
DROP TABLE IF EXISTS `invite_code`;
CREATE TABLE `invite_code` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`code`  varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`use_role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `limit_hero`
-- ----------------------------
DROP TABLE IF EXISTS `limit_hero`;
CREATE TABLE `limit_hero` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`today_refresh_date`  datetime NULL DEFAULT NULL ,
`today_script_ids`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`week_refresh_date`  datetime NULL DEFAULT NULL ,
`week_script_id`  int(11) NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `mail`
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`acceptor_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attachments`  varchar(4096) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`body`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`sender_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`source`  int(11) NOT NULL ,
`title`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`params`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `operation_log`
-- ----------------------------
DROP TABLE IF EXISTS `operation_log`;
CREATE TABLE `operation_log` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`creat_time`  datetime NOT NULL ,
`exp`  int(11) NOT NULL ,
`jinbi`  bigint(20) NOT NULL ,
`level`  int(11) NOT NULL ,
`operation`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`params`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`skill_point`  int(11) NOT NULL ,
`vit`  int(11) NOT NULL ,
`yuanbao`  int(11) NOT NULL ,
`vip_level`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=1

;

-- ----------------------------
-- Table structure for `red_packet`
-- ----------------------------
DROP TABLE IF EXISTS `red_packet`;
CREATE TABLE `red_packet` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`sender_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`task_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`account`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`reg_channel`  int(11) NOT NULL ,
`buy_jinbi_num`  int(11) NULL DEFAULT 0 ,
`buy_jinbi_time`  datetime NULL DEFAULT NULL ,
`buy_junling_num`  int(11) NULL DEFAULT 0 ,
`buy_junling_time`  datetime NULL DEFAULT NULL ,
`chapter_tag`  varchar(2048) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`complete_guide`  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '[]' ,
`create_time`  datetime NOT NULL ,
`faction_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`head_image`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' ,
`hero_skill_buy_count`  int(11) NOT NULL DEFAULT 0 ,
`hero_skill_buy_time`  datetime NULL DEFAULT NULL ,
`hero_skill_point`  int(11) NOT NULL DEFAULT 20 ,
`last_buy_item_date`  datetime NULL DEFAULT NULL ,
`last_salary_date`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`last_time_battle_date`  datetime NULL DEFAULT NULL ,
`level`  int(11) NOT NULL ,
`login_time`  datetime NULL DEFAULT NULL ,
`logout_time`  datetime NULL DEFAULT NULL ,
`market_charm`  int(11) NOT NULL DEFAULT 0 ,
`name`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`next_hero_skill_time`  datetime NULL DEFAULT NULL ,
`online_time`  int(11) NOT NULL ,
`prestige`  int(11) NOT NULL ,
`rename_count`  int(11) NOT NULL DEFAULT 0 ,
`sex`  int(11) NOT NULL DEFAULT 1 ,
`silence_expire`  datetime NULL DEFAULT NULL ,
`state`  smallint(6) NOT NULL ,
`support_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`version`  int(11) NOT NULL DEFAULT 0 ,
`vit`  int(11) NOT NULL DEFAULT 100 ,
`vit_date`  datetime NULL DEFAULT NULL ,
`vit_num`  int(11) NOT NULL DEFAULT 0 ,
`vit_reset_date`  datetime NULL DEFAULT NULL ,
`buy_hudong_count`  int(11) NULL DEFAULT 0 ,
`last_hudong_date`  datetime NULL DEFAULT NULL ,
`worship_count`  int(11) NULL DEFAULT 0 ,
`last_rename_time`  datetime NULL DEFAULT NULL ,
`combat_power`  int(11) NULL DEFAULT 0 ,
`chip_rob_stat`  int(11) NULL DEFAULT 0 ,
`quit_faction_date`  datetime NULL DEFAULT NULL ,
`sign_count_for_tc`  int(11) NOT NULL DEFAULT 0 ,
`last_answer_date`  datetime NULL DEFAULT NULL ,
`consume_yuanbao`  int(11) NOT NULL DEFAULT 0 ,
`last_consume_time`  datetime NULL DEFAULT NULL ,
`invite_code`  varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`invite_num`  int(11) NULL DEFAULT 0 ,
`next_junling_time`  datetime NULL DEFAULT NULL ,
`day_consume_yuanbao`  int(11) NULL DEFAULT 0 ,
`big_day_consume_yuanbao`  int(11) NULL DEFAULT 0 ,
`big_consume_yuanbao`  int(11) NULL DEFAULT 0 ,
`total_warmup_count`  int(11) NOT NULL ,
`win_warmup_count`  int(11) NOT NULL ,
`lose_warmup_count`  int(11) NOT NULL ,
`warmup_update_time`  datetime NULL DEFAULT NULL ,
`first_in_time`  bigint(20) NULL DEFAULT 0 ,
`is_receive_cornucopia`  int(1) NOT NULL DEFAULT 0 ,
`double_exp_out_time`  datetime NULL DEFAULT NULL ,
`double_item_out_time`  datetime NULL DEFAULT NULL ,
`server_id`  int(11) NOT NULL ,
`achieve_completed_num`  int(6) NULL DEFAULT 0 ,
`warmup_escape_count`  int(11) NOT NULL ,
`warmup_escape_time`  datetime NULL DEFAULT NULL ,
`copy_buff`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
UNIQUE INDEX `name` (`name`) USING BTREE ,
INDEX `index_account` (`account`) USING BTREE ,
INDEX `index_server_id` (`server_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_achieve`
-- ----------------------------
DROP TABLE IF EXISTS `role_achieve`;
CREATE TABLE `role_achieve` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`progress`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`continue_day_info`  varchar(600) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`received`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`rec_time`  datetime NULL DEFAULT NULL ,
`update_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_activity_sum_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_activity_sum_charge`;
CREATE TABLE `role_activity_sum_charge` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `fk_charge_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_activity_sum_consume`
-- ----------------------------
DROP TABLE IF EXISTS `role_activity_sum_consume`;
CREATE TABLE `role_activity_sum_consume` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `fk_consume_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_announce`
-- ----------------------------
DROP TABLE IF EXISTS `role_announce`;
CREATE TABLE `role_announce` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`announce_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK9C816A12E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_api`
-- ----------------------------
DROP TABLE IF EXISTS `role_api`;
CREATE TABLE `role_api` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`act_id`  int(11) NOT NULL ,
`acc_count`  int(11) NOT NULL DEFAULT 0 ,
`rewards_history`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '已领奖等级,eg: 2,4,6' ,
`update_time`  datetime NOT NULL ,
`create_time`  datetime NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK_ra_role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_arena_rank`
-- ----------------------------
DROP TABLE IF EXISTS `role_arena_rank`;
CREATE TABLE `role_arena_rank` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attack_fight_sum`  int(11) NULL DEFAULT 1 ,
`attack_win_sum`  int(11) NULL DEFAULT 1 ,
`challenge`  int(11) NULL DEFAULT 0 ,
`challenge_buy`  int(11) NULL DEFAULT 0 ,
`challenge_buy_date`  datetime NULL DEFAULT NULL ,
`challenge_money`  int(11) NULL DEFAULT 0 ,
`clear_cd_Date`  datetime NULL DEFAULT NULL ,
`clear_cd_num`  int(11) NULL DEFAULT 0 ,
`exchange_item_str`  varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`exchange_refresh_date`  datetime NULL DEFAULT NULL ,
`exchange_refresh_num`  int(11) NULL DEFAULT 0 ,
`fight_date`  datetime NULL DEFAULT NULL ,
`guard_fight_sum`  int(11) NULL DEFAULT 1 ,
`guard_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`guard_win_num`  int(11) NULL DEFAULT 0 ,
`guard_win_sum`  int(11) NULL DEFAULT 1 ,
`max_rank`  int(11) NULL DEFAULT 0 ,
`show_report_date`  datetime NULL DEFAULT NULL ,
`sneer_id`  int(11) NULL DEFAULT 0 ,
`sneer_str`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_arena_rank_fight`
-- ----------------------------
DROP TABLE IF EXISTS `role_arena_rank_fight`;
CREATE TABLE `role_arena_rank_fight` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fight_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`fight_time`  datetime NULL DEFAULT NULL ,
`flag`  int(11) NULL DEFAULT NULL ,
`rank_change`  int(11) NULL DEFAULT NULL ,
`rank_current`  int(11) NULL DEFAULT 0 ,
`reward`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`rival_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`sneer_id`  int(11) NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  int(11) NULL DEFAULT NULL ,
`movie_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FKE9415B1E2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_attack_castle`
-- ----------------------------
DROP TABLE IF EXISTS `role_attack_castle`;
CREATE TABLE `role_attack_castle` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`current_node_id`  int(11) NOT NULL DEFAULT 0 ,
`coin_count`  int(11) NOT NULL DEFAULT 0 ,
`reset_node_count`  int(11) NOT NULL DEFAULT 0 ,
`refresh_shop_count`  int(11) NOT NULL DEFAULT 0 ,
`last_reset_shop_date`  datetime NOT NULL ,
`last_reset_node_date`  datetime NULL DEFAULT NULL ,
`extra_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_auction_house`
-- ----------------------------
DROP TABLE IF EXISTS `role_auction_house`;
CREATE TABLE `role_auction_house` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`money`  bigint(20) NOT NULL DEFAULT 0 ,
`update_time`  datetime NOT NULL ,
`refresh_shop_times`  int(11) NULL DEFAULT 0 ,
`last_refresh_date`  datetime NULL DEFAULT NULL ,
`shop_item_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_big_activity_sum_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_big_activity_sum_charge`;
CREATE TABLE `role_big_activity_sum_charge` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_big_activity_sum_consume`
-- ----------------------------
DROP TABLE IF EXISTS `role_big_activity_sum_consume`;
CREATE TABLE `role_big_activity_sum_consume` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_big_day_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_big_day_charge`;
CREATE TABLE `role_big_day_charge` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NULL DEFAULT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_big_day_consume`
-- ----------------------------
DROP TABLE IF EXISTS `role_big_day_consume`;
CREATE TABLE `role_big_day_consume` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NULL DEFAULT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_blue_smithy`
-- ----------------------------
DROP TABLE IF EXISTS `role_blue_smithy`;
CREATE TABLE `role_blue_smithy` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`exchange_item_str`  varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`exchange_refresh_date`  datetime NULL DEFAULT NULL ,
`exchange_refresh_num`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_cdk_record`
-- ----------------------------
DROP TABLE IF EXISTS `role_cdk_record`;
CREATE TABLE `role_cdk_record` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`category`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`cdk`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK1411556F2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_charge`;
CREATE TABLE `role_charge` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`charge_template_id`  int(11) NOT NULL ,
`create_time`  datetime NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`charge_money`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_chat_set`
-- ----------------------------
DROP TABLE IF EXISTS `role_chat_set`;
CREATE TABLE `role_chat_set` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`faction_set`  int(11) NOT NULL ,
`faction_user_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`group_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`group_set`  int(11) NOT NULL ,
`group_user_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`private_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`private_set`  int(11) NOT NULL ,
`private_user_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`world_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`world_set`  int(11) NOT NULL ,
`world_user_color`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK18EBE8A42AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_chat_vote_forbidden`
-- ----------------------------
DROP TABLE IF EXISTS `role_chat_vote_forbidden`;
CREATE TABLE `role_chat_vote_forbidden` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`target_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`vote_ids`  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`add_time`  datetime NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`target_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK_chat_vote` (`role_id`) USING BTREE ,
INDEX `FK_chat_vote_target` (`target_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_chest_mock`
-- ----------------------------
DROP TABLE IF EXISTS `role_chest_mock`;
CREATE TABLE `role_chest_mock` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`num`  int(11) NOT NULL ,
`template_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_collect_soul`
-- ----------------------------
DROP TABLE IF EXISTS `role_collect_soul`;
CREATE TABLE `role_collect_soul` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`collect_type`  int(11) NOT NULL ,
`collect_count`  int(11) NOT NULL DEFAULT 0 ,
`last_refresh_time`  datetime NOT NULL ,
`view_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_copy`
-- ----------------------------
DROP TABLE IF EXISTS `role_copy`;
CREATE TABLE `role_copy` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`count_today`  smallint(6) NOT NULL ,
`count_total`  int(11) NOT NULL ,
`last_time`  datetime NOT NULL ,
`star`  tinyint(4) NOT NULL ,
`template_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`hudong_count`  int(11) NULL DEFAULT 0 ,
`last_hudong_date`  datetime NULL DEFAULT NULL ,
`buy_reset_count`  int(11) NULL DEFAULT 0 ,
`last_buy_reset_time`  datetime NULL DEFAULT NULL ,
`levy_date`  datetime NULL DEFAULT NULL ,
`occupy_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK13FFC19E2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_cornucopia`
-- ----------------------------
DROP TABLE IF EXISTS `role_cornucopia`;
CREATE TABLE `role_cornucopia` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`buy_date`  datetime NULL DEFAULT NULL ,
`last_receive_date`  datetime NULL DEFAULT NULL ,
`script_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_day_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_day_charge`;
CREATE TABLE `role_day_charge` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NULL DEFAULT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKE06EA420E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_day_consume`
-- ----------------------------
DROP TABLE IF EXISTS `role_day_consume`;
CREATE TABLE `role_day_consume` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NULL DEFAULT NULL ,
`threshold`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK3A0FA810E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_dayforverlogin`
-- ----------------------------
DROP TABLE IF EXISTS `role_dayforverlogin`;
CREATE TABLE `role_dayforverlogin` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_levelrewards`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`day_count`  int(11) NULL DEFAULT 0 ,
`last_login_time`  datetime NULL DEFAULT NULL ,
`last_update_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_daylogin`
-- ----------------------------
DROP TABLE IF EXISTS `role_daylogin`;
CREATE TABLE `role_daylogin` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_levelrewards`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`day_count`  int(11) NULL DEFAULT 0 ,
`last_login_time`  datetime NULL DEFAULT NULL ,
`last_update_time`  datetime NULL DEFAULT NULL ,
`start_time`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_exchange_item`
-- ----------------------------
DROP TABLE IF EXISTS `role_exchange_item`;
CREATE TABLE `role_exchange_item` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' ,
`exchange_counts`  int(11) NULL DEFAULT NULL ,
`exchange_no`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`exchange_out`  bit(1) NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`last_exchange_item_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK2697A2332GB21D7Z` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_faction`
-- ----------------------------
DROP TABLE IF EXISTS `role_faction`;
CREATE TABLE `role_faction` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`buy_shop_ids`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`copy_award_num`  int(11) NOT NULL ,
`shop_refresh_date`  datetime NULL DEFAULT NULL ,
`copy_challenge_num`  int(11) NOT NULL ,
`limit_time_award_num`  int(11) NOT NULL ,
`receive_award_date`  datetime NULL DEFAULT NULL ,
`refresh_challenge_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_firstjia`
-- ----------------------------
DROP TABLE IF EXISTS `role_firstjia`;
CREATE TABLE `role_firstjia` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_levelrewards`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`last_update_time`  datetime NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_formation`
-- ----------------------------
DROP TABLE IF EXISTS `role_formation`;
CREATE TABLE `role_formation` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`config`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`group_index`  tinyint(4) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKFFB68282AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_fortune_wheel`
-- ----------------------------
DROP TABLE IF EXISTS `role_fortune_wheel`;
CREATE TABLE `role_fortune_wheel` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`total_count`  int(11) NOT NULL DEFAULT 0 ,
`last_count`  int(11) NOT NULL DEFAULT 0 ,
`charge_count`  int(11) NOT NULL DEFAULT 0 ,
`update_time`  datetime NOT NULL ,
`activity_start_time`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_fourth_test`
-- ----------------------------
DROP TABLE IF EXISTS `role_fourth_test`;
CREATE TABLE `role_fourth_test` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`charge_return`  bit(1) NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_friends_invitation`
-- ----------------------------
DROP TABLE IF EXISTS `role_friends_invitation`;
CREATE TABLE `role_friends_invitation` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`recall_code`  varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`consume_amount`  int(11) NOT NULL DEFAULT 0 ,
`max_level`  int(11) NOT NULL DEFAULT 0 ,
`create_time`  datetime NOT NULL ,
PRIMARY KEY (`role_id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_friends_recalled`
-- ----------------------------
DROP TABLE IF EXISTS `role_friends_recalled`;
CREATE TABLE `role_friends_recalled` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`invite_role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '\"\"' ,
`sign_count`  int(11) NOT NULL DEFAULT 0 ,
`charge_amount`  int(11) NOT NULL DEFAULT 0 ,
`state`  tinyint(4) NOT NULL COMMENT '0：已符合离线天数；1: 已打开过界面；2：已被召回' ,
`recall_time`  datetime NOT NULL ,
PRIMARY KEY (`role_id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_fund`
-- ----------------------------
DROP TABLE IF EXISTS `role_fund`;
CREATE TABLE `role_fund` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_rewards`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`buy_fund`  int(11) NOT NULL DEFAULT 0 ,
`last_update_time`  datetime NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_haoqingbao`
-- ----------------------------
DROP TABLE IF EXISTS `role_haoqingbao`;
CREATE TABLE `role_haoqingbao` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`yuanbao_num`  int(11) NOT NULL DEFAULT 0 ,
`recv_num`  int(11) NOT NULL DEFAULT 0 ,
`total_count`  bigint(20) NOT NULL DEFAULT 0 ,
`total_num`  bigint(20) NOT NULL DEFAULT 0 ,
`send_num`  int(11) NOT NULL DEFAULT 0 ,
`last_recv_time`  datetime NULL DEFAULT NULL ,
`update_time`  datetime NOT NULL ,
`lucky_star_count`  int(11) NOT NULL DEFAULT 0 ,
`total_send_count`  bigint(20) NOT NULL DEFAULT 0 ,
`total_send_sum`  bigint(20) NOT NULL DEFAULT 0 ,
`last_charge_status_time`  bigint(20) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_haoqingbao_item`
-- ----------------------------
DROP TABLE IF EXISTS `role_haoqingbao_item`;
CREATE TABLE `role_haoqingbao_item` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`send_range`  int(11) NOT NULL DEFAULT 0 ,
`type`  int(11) NOT NULL DEFAULT 0 ,
`min_level`  int(11) NOT NULL DEFAULT 0 ,
`min_vip_level`  int(11) NOT NULL DEFAULT 0 ,
`min_friend_point`  int(11) NOT NULL DEFAULT 0 ,
`total_num`  int(11) NOT NULL DEFAULT 0 ,
`redpacket_num`  int(11) NOT NULL DEFAULT 0 ,
`received_num`  int(11) NOT NULL DEFAULT 0 ,
`msg`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`faction_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`start_time`  datetime NOT NULL ,
`last_recv_time`  datetime NULL DEFAULT NULL ,
`finished`  int(11) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_haoqingbao_record`
-- ----------------------------
DROP TABLE IF EXISTS `role_haoqingbao_record`;
CREATE TABLE `role_haoqingbao_record` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`yuanbao_num`  int(11) NOT NULL DEFAULT 0 ,
`description`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`update_time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_haoqingbao_redpacket_record`
-- ----------------------------
DROP TABLE IF EXISTS `role_haoqingbao_redpacket_record`;
CREATE TABLE `role_haoqingbao_redpacket_record` (
`id`  bigint(20) NOT NULL AUTO_INCREMENT ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`redpacket_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`num`  int(11) NOT NULL DEFAULT 0 ,
`lucky_star`  int(11) NOT NULL DEFAULT 0 ,
`recv_date`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=82

;

-- ----------------------------
-- Table structure for `role_hero`
-- ----------------------------
DROP TABLE IF EXISTS `role_hero`;
CREATE TABLE `role_hero` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attach_data`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`color`  tinyint(4) NOT NULL ,
`break_level`  tinyint(4) NOT NULL ,
`equip_config`  longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`exp`  int(11) NOT NULL ,
`level`  int(11) NOT NULL ,
`star`  tinyint(4) NOT NULL ,
`template_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`special_attendant`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK1401E2232AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_hero_admire`
-- ----------------------------
DROP TABLE IF EXISTS `role_hero_admire`;
CREATE TABLE `role_hero_admire` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`hero_id`  int(11) NULL DEFAULT 0 ,
`hero_list`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`hero_refresh_date`  datetime NULL DEFAULT NULL ,
`item_list`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`item_refresh_date`  datetime NULL DEFAULT NULL ,
`value`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_hero_relation`
-- ----------------------------
DROP TABLE IF EXISTS `role_hero_relation`;
CREATE TABLE `role_hero_relation` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`hero_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`level`  int(11) NOT NULL ,
`template_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
INDEX `hero_index` (`hero_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_hero_skill`
-- ----------------------------
DROP TABLE IF EXISTS `role_hero_skill`;
CREATE TABLE `role_hero_skill` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`level`  int(11) NOT NULL ,
`template_id`  int(11) NOT NULL ,
`hero_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`hero_id`) REFERENCES `role_hero` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK73ADA93527208E13` (`hero_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_invite_activity`
-- ----------------------------
DROP TABLE IF EXISTS `role_invite_activity`;
CREATE TABLE `role_invite_activity` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`threshold`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_invite_log`
-- ----------------------------
DROP TABLE IF EXISTS `role_invite_log`;
CREATE TABLE `role_invite_log` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_date`  datetime NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`target_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`mac`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_item`
-- ----------------------------
DROP TABLE IF EXISTS `role_item`;
CREATE TABLE `role_item` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attach_data`  varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`delete_time`  datetime NULL DEFAULT NULL ,
`num`  int(11) NOT NULL ,
`template_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_item_chip`
-- ----------------------------
DROP TABLE IF EXISTS `role_item_chip`;
CREATE TABLE `role_item_chip` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`formation_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`num`  int(11) NOT NULL ,
`template_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK2459A56F2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_item_chip_fight`
-- ----------------------------
DROP TABLE IF EXISTS `role_item_chip_fight`;
CREATE TABLE `role_item_chip_fight` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`chip_Template_Id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fight_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fight_time`  datetime NOT NULL ,
`flag`  int(11) NOT NULL ,
`num`  int(11) NOT NULL ,
`rival_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FKB988A1402AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_ladder`
-- ----------------------------
DROP TABLE IF EXISTS `role_ladder`;
CREATE TABLE `role_ladder` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`challenge_buy_date`  datetime NULL DEFAULT NULL ,
`challenge_buy_num`  int(11) NULL DEFAULT 0 ,
`challenge_remain`  int(11) NULL DEFAULT 0 ,
`guard_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`ladder_level`  int(11) NULL DEFAULT 0 ,
`ladder_star`  int(11) NULL DEFAULT 0 ,
`reward_str`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`show_report_date`  datetime NULL DEFAULT NULL ,
`win_num`  int(11) NULL DEFAULT 0 ,
`season_date`  datetime NOT NULL ,
`change_level_date`  datetime NOT NULL ,
`ladder_score`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_ladder_report`
-- ----------------------------
DROP TABLE IF EXISTS `role_ladder_report`;
CREATE TABLE `role_ladder_report` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fight_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fight_time`  datetime NOT NULL ,
`level_change`  int(11) NULL DEFAULT 0 ,
`rival_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`rival_level`  int(11) NULL DEFAULT 0 ,
`star_change`  int(11) NULL DEFAULT 0 ,
`state`  int(11) NULL DEFAULT 0 ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK3BA4CFE8E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_level_weal`
-- ----------------------------
DROP TABLE IF EXISTS `role_level_weal`;
CREATE TABLE `role_level_weal` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accept_count`  int(11) NULL DEFAULT 0 ,
`extra_accept_count`  int(11) NULL DEFAULT 0 ,
`last_accept_date`  datetime NULL DEFAULT NULL ,
`update_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_levelreward`
-- ----------------------------
DROP TABLE IF EXISTS `role_levelreward`;
CREATE TABLE `role_levelreward` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_levelrewards`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`last_update_time`  datetime NOT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_limit_hero`
-- ----------------------------
DROP TABLE IF EXISTS `role_limit_hero`;
CREATE TABLE `role_limit_hero` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`buy_count`  int(11) NOT NULL ,
`buy_yuanbao`  int(11) NOT NULL ,
`last_buy_date`  datetime NULL DEFAULT NULL ,
`today_buy_count`  int(11) NOT NULL ,
`item_buy_count`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_lucky_bag`
-- ----------------------------
DROP TABLE IF EXISTS `role_lucky_bag`;
CREATE TABLE `role_lucky_bag` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`script_Id`  int(11) NOT NULL ,
`TYPE`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_mail`
-- ----------------------------
DROP TABLE IF EXISTS `role_mail`;
CREATE TABLE `role_mail` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`acceptor_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`attachments`  varchar(4096) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`body`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`sender_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sender_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`state`  int(11) NOT NULL ,
`templ_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`title`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK140417E02AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_mail_history`
-- ----------------------------
DROP TABLE IF EXISTS `role_mail_history`;
CREATE TABLE `role_mail_history` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`templ_id`  longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK75ADC3352AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_market`
-- ----------------------------
DROP TABLE IF EXISTS `role_market`;
CREATE TABLE `role_market` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`first`  bit(1) NULL DEFAULT NULL ,
`free_num`  int(11) NOT NULL ,
`last_free_time`  datetime NULL DEFAULT NULL ,
`type`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
INDEX `index_role` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_mock`
-- ----------------------------
DROP TABLE IF EXISTS `role_mock`;
CREATE TABLE `role_mock` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`template_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`sucess_num`  int(11) NOT NULL ,
`total_num`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK14044BB3E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_online`
-- ----------------------------
DROP TABLE IF EXISTS `role_online`;
CREATE TABLE `role_online` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`item_view`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`online_id`  int(11) NOT NULL ,
`req_time`  int(11) NOT NULL ,
`reward_num`  int(11) NOT NULL ,
`star_date`  datetime NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK277FE23C2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_opened_menu`
-- ----------------------------
DROP TABLE IF EXISTS `role_opened_menu`;
CREATE TABLE `role_opened_menu` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`open_hero_admire_date`  datetime NULL DEFAULT NULL ,
`open_hero_call_date`  datetime NULL DEFAULT NULL ,
`open_make_vip_date`  datetime NULL DEFAULT NULL ,
`open_announce_date`  datetime NULL DEFAULT NULL ,
`open_vip_gift_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_partner`
-- ----------------------------
DROP TABLE IF EXISTS `role_partner`;
CREATE TABLE `role_partner` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`config`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`max_pos`  int(11) NULL DEFAULT 1 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_powerreward`
-- ----------------------------
DROP TABLE IF EXISTS `role_powerreward`;
CREATE TABLE `role_powerreward` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_update_time`  datetime NOT NULL ,
`accepted_powerrewards`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_recall_task`
-- ----------------------------
DROP TABLE IF EXISTS `role_recall_task`;
CREATE TABLE `role_recall_task` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`task_id`  int(11) NOT NULL ,
`state`  tinyint(4) NOT NULL COMMENT '0: 未完成; 1:已完成,待领奖; 2:已领奖' ,
`create_time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_red_packet`
-- ----------------------------
DROP TABLE IF EXISTS `role_red_packet`;
CREATE TABLE `role_red_packet` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`red_packet_ids`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`is_tong_guan`  bit(1) NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK1DD90B5FE29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_seckill`
-- ----------------------------
DROP TABLE IF EXISTS `role_seckill`;
CREATE TABLE `role_seckill` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`seckill_date`  datetime NULL DEFAULT NULL ,
`seckill_id`  int(11) NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK8C3BB866E29D9213` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_send_junling`
-- ----------------------------
DROP TABLE IF EXISTS `role_send_junling`;
CREATE TABLE `role_send_junling` (
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`accepted_rewardindex`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`last_accepted_time`  datetime NULL DEFAULT NULL ,
`last_update_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_seven_progress`
-- ----------------------------
DROP TABLE IF EXISTS `role_seven_progress`;
CREATE TABLE `role_seven_progress` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`s_id`  int(8) NOT NULL ,
`progress`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`rec_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_seven_task`
-- ----------------------------
DROP TABLE IF EXISTS `role_seven_task`;
CREATE TABLE `role_seven_task` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`three_star_rec`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`star_award_rec`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`total_star`  int(8) NULL DEFAULT 0 ,
`join_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_shop_item`
-- ----------------------------
DROP TABLE IF EXISTS `role_shop_item`;
CREATE TABLE `role_shop_item` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`buy_times`  int(11) NOT NULL ,
`item_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  int(11) NOT NULL DEFAULT 0 ,
`use_out`  bit(1) NOT NULL DEFAULT b'0' ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK2697A2332AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_sign`
-- ----------------------------
DROP TABLE IF EXISTS `role_sign`;
CREATE TABLE `role_sign` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`date`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`roulette_times`  int(11) NOT NULL DEFAULT 0 ,
`sign_times`  int(11) NOT NULL DEFAULT 0 ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`resign_flag`  int(1) NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK1406EFE62AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_smithy`
-- ----------------------------
DROP TABLE IF EXISTS `role_smithy`;
CREATE TABLE `role_smithy` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`exchange_item_str`  varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`exchange_refresh_date`  datetime NULL DEFAULT NULL ,
`exchange_refresh_num`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_sns`
-- ----------------------------
DROP TABLE IF EXISTS `role_sns`;
CREATE TABLE `role_sns` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  int(11) NOT NULL ,
`target`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`friend_point`  int(11) NULL DEFAULT 0 ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`send_junling_num`  int(11) NULL DEFAULT 0 ,
`accept_junling_num`  int(11) NULL DEFAULT 0 ,
`accept_junling_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKF021422F2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_sns_junling_limit`
-- ----------------------------
DROP TABLE IF EXISTS `role_sns_junling_limit`;
CREATE TABLE `role_sns_junling_limit` (
`id`  bigint(20) NOT NULL AUTO_INCREMENT ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`target_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`send_num`  int(11) NULL DEFAULT 0 ,
`send_time`  datetime NULL DEFAULT NULL ,
`recv_num`  int(11) NULL DEFAULT 0 ,
`recv_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=384

;

-- ----------------------------
-- Table structure for `role_super_charge`
-- ----------------------------
DROP TABLE IF EXISTS `role_super_charge`;
CREATE TABLE `role_super_charge` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`script_Id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`charge_amount`  int(11) NULL DEFAULT 0 ,
`raffle_num`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_super_turntable`
-- ----------------------------
DROP TABLE IF EXISTS `role_super_turntable`;
CREATE TABLE `role_super_turntable` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_receive_time`  datetime NOT NULL ,
`script_Id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_name`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`announce_flag`  int(2) NULL DEFAULT 0 ,
`vip_level`  int(8) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_task`
-- ----------------------------
DROP TABLE IF EXISTS `role_task`;
CREATE TABLE `role_task` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`num`  int(11) NOT NULL ,
`star`  int(11) NOT NULL ,
`state`  int(11) NOT NULL ,
`task_date`  datetime NOT NULL ,
`task_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK140747AE2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_task_apoint`
-- ----------------------------
DROP TABLE IF EXISTS `role_task_apoint`;
CREATE TABLE `role_task_apoint` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`point`  int(11) NULL DEFAULT 0 ,
`received`  varchar(350) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`rec_time`  datetime NULL DEFAULT NULL ,
`update_time`  datetime NULL DEFAULT NULL ,
`max_quality_level`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_time_battle`
-- ----------------------------
DROP TABLE IF EXISTS `role_time_battle`;
CREATE TABLE `role_time_battle` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`challenge_times`  int(11) NOT NULL ,
`pass_id`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`last_pass_date`  datetime NULL DEFAULT NULL ,
`max_star`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FKBC3988212AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_total_sign_gift`
-- ----------------------------
DROP TABLE IF EXISTS `role_total_sign_gift`;
CREATE TABLE `role_total_sign_gift` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`gift_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`month`  int(11) NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK24800D6E2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_trader`
-- ----------------------------
DROP TABLE IF EXISTS `role_trader`;
CREATE TABLE `role_trader` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`call_result`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`hero_call_result`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`hero_jinbi_count`  int(11) NOT NULL DEFAULT 0 ,
`hero_yuanbao_count`  int(11) NOT NULL DEFAULT 0 ,
`jinbi_count`  int(11) NOT NULL ,
`last_call_time`  datetime NULL DEFAULT NULL ,
`last_hero_time`  datetime NULL DEFAULT NULL ,
`yuanbao_count`  int(11) NOT NULL ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_treasure`
-- ----------------------------
DROP TABLE IF EXISTS `role_treasure`;
CREATE TABLE `role_treasure` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`depart_date`  datetime NULL DEFAULT NULL ,
`hero_ids`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`recommend_hero_json`  varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`recommend_hero_num`  int(11) NULL DEFAULT NULL ,
`refresh_date`  datetime NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`group_num`  int(11) NULL DEFAULT 1 ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_up_gift`
-- ----------------------------
DROP TABLE IF EXISTS `role_up_gift`;
CREATE TABLE `role_up_gift` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`info_id`  int(11) NOT NULL ,
`time`  datetime NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK8934D8B2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_validation`
-- ----------------------------
DROP TABLE IF EXISTS `role_validation`;
CREATE TABLE `role_validation` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`type`  int(11) NOT NULL DEFAULT 0 ,
`refer_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`tag`  varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`reason`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`update_date`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=13

;

-- ----------------------------
-- Table structure for `role_vip`
-- ----------------------------
DROP TABLE IF EXISTS `role_vip`;
CREATE TABLE `role_vip` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`bind_yuanbao`  int(11) NOT NULL ,
`jinbi`  bigint(20) NOT NULL ,
`jinbi_history`  bigint(20) NOT NULL DEFAULT 0 ,
`last_refreshing_vip_trader_time`  datetime NULL DEFAULT NULL ,
`month_expire_time`  datetime NULL DEFAULT NULL ,
`unbind_yuanbao`  int(11) NOT NULL ,
`vip_experience`  int(11) NOT NULL DEFAULT 0 ,
`vip_level`  int(11) NOT NULL DEFAULT 0 ,
`charge_history`  int(20) NOT NULL DEFAULT 0 ,
`year_expire_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`),
UNIQUE INDEX `role_id` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_vip_gift_packs`
-- ----------------------------
DROP TABLE IF EXISTS `role_vip_gift_packs`;
CREATE TABLE `role_vip_gift_packs` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`vip_level`  int(11) NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role_vip` (`role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKDC6F85F672CDCFE8` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_vip_trader_item`
-- ----------------------------
DROP TABLE IF EXISTS `role_vip_trader_item`;
CREATE TABLE `role_vip_trader_item` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`bought_today`  bit(1) NOT NULL ,
`count`  int(11) NOT NULL ,
`item_tid`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role_vip` (`role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKB5000E3972CDCFE8` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_vit_receive`
-- ----------------------------
DROP TABLE IF EXISTS `role_vit_receive`;
CREATE TABLE `role_vit_receive` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`receive_date`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`send_date`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '20101001' ,
`sender`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK76E50E7C2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_vit_send`
-- ----------------------------
DROP TABLE IF EXISTS `role_vit_send`;
CREATE TABLE `role_vit_send` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`send_date`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`target`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK22D5828F2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_world_boss`
-- ----------------------------
DROP TABLE IF EXISTS `role_world_boss`;
CREATE TABLE `role_world_boss` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`challenge_date`  datetime NULL DEFAULT NULL ,
`inspire_type`  int(11) NULL DEFAULT NULL ,
`inspire_value`  int(11) NULL DEFAULT NULL ,
`gain_item_num`  int(11) NULL DEFAULT 0 ,
`gain_item_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_worship`
-- ----------------------------
DROP TABLE IF EXISTS `role_worship`;
CREATE TABLE `role_worship` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`by_worship`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`copy_id`  int(11) NOT NULL ,
`worship_date`  datetime NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK71BC1B0D2AB21C7D` (`role_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `seckill_item`
-- ----------------------------
DROP TABLE IF EXISTS `seckill_item`;
CREATE TABLE `seckill_item` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`buy_num`  int(11) NULL DEFAULT NULL ,
`seckill_id`  int(11) NULL DEFAULT NULL ,
`create_date`  datetime NULL DEFAULT '2015-05-28 00:00:00' ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `server_activity`
-- ----------------------------
DROP TABLE IF EXISTS `server_activity`;
CREATE TABLE `server_activity` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`activity_id`  int(11) NOT NULL ,
`reader`  text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`server_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`server_id`) REFERENCES `server_config` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FK65EC708B18E0B7F` (`server_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=1

;

-- ----------------------------
-- Table structure for `server_config`
-- ----------------------------
DROP TABLE IF EXISTS `server_config`;
CREATE TABLE `server_config` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`open_time`  datetime NOT NULL ,
`sequence`  bigint(20) NOT NULL ,
`faction_seq`  bigint(20) NULL DEFAULT 1000 ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2

;

-- ----------------------------
-- Table structure for `server_copy`
-- ----------------------------
DROP TABLE IF EXISTS `server_copy`;
CREATE TABLE `server_copy` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`champion_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`template_id`  int(11) NOT NULL ,
`server_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`server_id`) REFERENCES `server_config` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FKD2C14AF118E0B7F` (`server_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=115423

;

-- ----------------------------
-- Table structure for `server_guide_counter`
-- ----------------------------
DROP TABLE IF EXISTS `server_guide_counter`;
CREATE TABLE `server_guide_counter` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`counter`  int(11) NOT NULL ,
`guide_id`  int(11) NOT NULL ,
`server_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`server_id`) REFERENCES `server_config` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FKFACB0BBDC54D8B15` (`server_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=1

;

-- ----------------------------
-- Table structure for `server_open_close_log`
-- ----------------------------
DROP TABLE IF EXISTS `server_open_close_log`;
CREATE TABLE `server_open_close_log` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`open_time`  datetime NOT NULL ,
`close_time`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`),
UNIQUE INDEX `id` (`id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=17

;

-- ----------------------------
-- Table structure for `server_performance`
-- ----------------------------
DROP TABLE IF EXISTS `server_performance`;
CREATE TABLE `server_performance` (
`id`  int(11) NOT NULL AUTO_INCREMENT ,
`avg_cost`  int(11) NOT NULL ,
`max_cost`  int(11) NOT NULL ,
`name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`process_count`  int(11) NOT NULL ,
`total_cost`  bigint(20) NOT NULL ,
`open_close_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`open_close_id`) REFERENCES `server_open_close_log` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
UNIQUE INDEX `id` (`id`) USING BTREE ,
INDEX `FKD42DD1345686D5D3` (`open_close_id`) USING BTREE 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2028

;

-- ----------------------------
-- Table structure for `shoot_score_rank`
-- ----------------------------
DROP TABLE IF EXISTS `shoot_score_rank`;
CREATE TABLE `shoot_score_rank` (
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`rank`  int(4) NULL DEFAULT 0 ,
`score`  int(4) NULL DEFAULT 0 ,
`score_recv_done`  int(4) NULL DEFAULT 0 ,
`total_score`  int(11) NULL DEFAULT 0 ,
`day_free_cnt`  int(4) NULL DEFAULT 0 ,
`day_one_cnt`  int(4) NULL DEFAULT 0 ,
`shoot_one_cnt`  int(4) NULL DEFAULT 0 ,
`shoot_ten_cnt`  int(4) NULL DEFAULT 0 ,
`shoot_free_time`  datetime NULL DEFAULT NULL ,
`shoot_ont_time`  datetime NULL DEFAULT NULL ,
`shoot_time`  datetime NOT NULL ,
`rec`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`role_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `temp`
-- ----------------------------
DROP TABLE IF EXISTS `temp`;
CREATE TABLE `temp` (
`old_value`  bigint(20) NOT NULL ,
`new_value`  bigint(20) NOT NULL ,
`create_time`  datetime NOT NULL 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `world_boss`
-- ----------------------------
DROP TABLE IF EXISTS `world_boss`;
CREATE TABLE `world_boss` (
`id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`boss_id`  int(11) NULL DEFAULT NULL ,
`boss_remain_blood`  bigint(20) NULL DEFAULT NULL ,
`boss_sum_blood`  bigint(20) NULL DEFAULT NULL ,
`count_rank_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`customs_id`  int(11) NULL DEFAULT NULL ,
`harm_rank_json`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`participator_ids`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`tail_award_json`  varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`boss_death_date`  datetime NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `worship_rank`
-- ----------------------------
DROP TABLE IF EXISTS `worship_rank`;
CREATE TABLE `worship_rank` (
`id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`role_name`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`worship_count`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;