CREATE TABLE `operation_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `creat_time` datetime NOT NULL,
  `exp` int(11) NOT NULL,
  `jinbi` bigint(20) NOT NULL,
  `level` int(11) NOT NULL,
  `operation` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `role_id` varchar(255) NOT NULL,
  `skill_point` int(11) NOT NULL,
  `vit` int(11) NOT NULL,
  `yuanbao` int(11) NOT NULL,
  `vip_level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;