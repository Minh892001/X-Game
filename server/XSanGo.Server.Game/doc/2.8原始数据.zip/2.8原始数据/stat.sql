SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account_operate_log`
-- ----------------------------
DROP TABLE IF EXISTS `account_operate_log`;
CREATE TABLE `account_operate_log` (
`id`  bigint(20) NOT NULL ,
`account`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`create_time`  datetime NOT NULL ,
`remark`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `charge_log`
-- ----------------------------
DROP TABLE IF EXISTS `charge_log`;
CREATE TABLE `charge_log` (
`order_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`account`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`cent`  int(11) NOT NULL ,
`create_time`  datetime NOT NULL ,
`server_id`  int(11) NOT NULL ,
`register_today`  int(11) NOT NULL ,
`charge_count`  int(11) NOT NULL ,
`card_type`  int(11) NULL DEFAULT 0 ,
`channel`  int(11) NULL DEFAULT 0 ,
`pm_id`  int(11) NULL DEFAULT 0 ,
PRIMARY KEY (`order_id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `level_spread`
-- ----------------------------
DROP TABLE IF EXISTS `level_spread`;
CREATE TABLE `level_spread` (
`id`  bigint(20) NOT NULL ,
`stat_date`  date NOT NULL ,
`server_id`  int(11) NOT NULL ,
`level`  smallint(6) NOT NULL ,
`num`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `login_log`
-- ----------------------------
DROP TABLE IF EXISTS `login_log`;
CREATE TABLE `login_log` (
`id`  bigint(20) NOT NULL ,
`account`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`channel`  int(11) NOT NULL ,
`login_time`  datetime NOT NULL ,
`mac`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`ip`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`client_version`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`install_sign`  varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `login_out_log`
-- ----------------------------
DROP TABLE IF EXISTS `login_out_log`;
CREATE TABLE `login_out_log` (
`id`  bigint(20) NOT NULL ,
`account`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`channel`  int(11) NOT NULL ,
`online_interval`  int(11) NOT NULL ,
`login_time`  datetime NOT NULL ,
`logout_time`  datetime NOT NULL ,
`role_id`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`server_id`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `online`
-- ----------------------------
DROP TABLE IF EXISTS `online`;
CREATE TABLE `online` (
`id`  int(11) NOT NULL ,
`online_count`  int(11) NOT NULL ,
`server_id`  int(11) NOT NULL ,
`stat_time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_create_log`
-- ----------------------------
DROP TABLE IF EXISTS `role_create_log`;
CREATE TABLE `role_create_log` (
`id`  bigint(20) NOT NULL ,
`account`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`server_id`  int(11) NOT NULL ,
`role_id`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`mac`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`ip`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`channel`  int(11) NOT NULL DEFAULT 10000 ,
`create_time`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `role_validate_info`
-- ----------------------------
DROP TABLE IF EXISTS `role_validate_info`;
CREATE TABLE `role_validate_info` (
`id`  int(11) NOT NULL ,
`account`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`role_id`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`server_id`  int(11) NOT NULL ,
`type`  int(11) NOT NULL ,
`tag`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,
`update_date`  datetime NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `stat_copy_progress`
-- ----------------------------
DROP TABLE IF EXISTS `stat_copy_progress`;
CREATE TABLE `stat_copy_progress` (
`id`  bigint(20) NOT NULL ,
`stat_date`  date NOT NULL ,
`server_id`  int(11) NOT NULL ,
`copy_id`  int(11) NOT NULL ,
`role_count`  int(11) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `stat_ecnomy`
-- ----------------------------
DROP TABLE IF EXISTS `stat_ecnomy`;
CREATE TABLE `stat_ecnomy` (
`id`  bigint(20) NOT NULL ,
`stat_date`  date NOT NULL ,
`server_id`  int(11) NOT NULL ,
`type`  int(11) NOT NULL ,
`consume`  bigint(20) NOT NULL ,
`produce`  bigint(20) NOT NULL ,
`total`  bigint(20) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Table structure for `stat_guide_progress`
-- ----------------------------
DROP TABLE IF EXISTS `stat_guide_progress`;
CREATE TABLE `stat_guide_progress` (
`id`  bigint(20) NOT NULL ,
`guide_id`  int(11) NOT NULL ,
`role_count`  int(11) NOT NULL ,
`server_id`  int(11) NOT NULL ,
`stat_date`  date NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci

;

-- ----------------------------
-- Indexes structure for table charge_log
-- ----------------------------
CREATE UNIQUE INDEX `order_id` ON `charge_log`(`order_id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table online
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `online`(`id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table stat_copy_progress
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `stat_copy_progress`(`id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table stat_ecnomy
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `stat_ecnomy`(`id`) USING BTREE ;

-- ----------------------------
-- Indexes structure for table stat_guide_progress
-- ----------------------------
CREATE UNIQUE INDEX `id` ON `stat_guide_progress`(`id`) USING BTREE ;
